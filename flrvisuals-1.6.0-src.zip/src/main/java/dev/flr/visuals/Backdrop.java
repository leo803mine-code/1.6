package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

/** Чёрный фон с «шёлковыми» волнами (как XMB на PS3) и звёздами, логотип и экран загрузки. */
final class Backdrop {
    private static final ResourceLocation LOGO = ResourceLocation.withDefaultNamespace("textures/gui/title/minecraft.png");

    private Backdrop() {}

    static void draw(GuiGraphics g, int w, int h) {
        float t = (System.currentTimeMillis() % 1_000_000L) / 1000f;
        int acc = Config.color() & 0xFFFFFF;
        g.fill(0, 0, w, h, 0xFF040409);
        g.fillGradient(0, h / 2, w, h, 0x00000000, 0x38000000 | acc);

        for (int i = 0; i < 70; i++) {
            float rx = frac((float) Math.sin(i * 12.9898) * 43758.5453f), ry = frac((float) Math.sin(i * 78.233) * 12345.678f);
            float x = (rx * w + t * (3 + i % 5)) % w, y = ry * h;
            float tw = 0.5f + 0.5f * (float) Math.sin(t * 1.4f + i);
            int a = (int) (30 + 110 * tw * (0.4f + 0.6f * frac(i * 0.37f)));
            int sz = i % 11 == 0 ? 2 : 1;
            g.fill((int) x, (int) y, (int) x + sz, (int) y + sz, (a << 24) | (i % 3 == 0 ? acc : 0xFFFFFF));
        }

        for (int r = 0; r < 4; r++) {
            float ph = r * 1.7f, base = h * (0.52f + 0.07f * r), amp = h * (0.055f + 0.012f * r);
            int ca = r % 2 == 0 ? 0xFFFFFF : acc;
            for (int x = 0; x < w; x += 4) {
                float yc = base + amp * (float) Math.sin(x * 0.0055f + t * 0.45f + ph)
                        + amp * 0.5f * (float) Math.sin(x * 0.012f - t * 0.3f + ph * 2f);
                float th = h * (0.012f + 0.03f * (0.5f + 0.5f * (float) Math.sin(x * 0.004f + t * 0.2f + ph)));
                g.fill(x, (int) (yc - th), x + 4, (int) (yc + th), 0x10000000 | ca);
                g.fill(x, (int) (yc - th * 0.55f), x + 4, (int) (yc + th * 0.55f), 0x1A000000 | ca);
                g.fill(x, (int) (yc - th * 0.14f), x + 4, (int) (yc + th * 0.14f) + 1, 0x40000000 | ca);
            }
        }
        g.fillGradient(0, 0, w, h / 4, 0xFF040409, 0x00040409);
    }

    private static float frac(float v) {
        return v - (float) Math.floor(v);
    }

    static void logo(GuiGraphics g, int w) {
        int x = w / 2 - 128;
        g.blit(LOGO, x, 30, 0f, 0f, 155, 44, 256, 64);
        g.blit(LOGO, x + 155, 30, 0f, 45f, 155, 44, 256, 64);
    }

    /** Экран загрузки: кольцо из точек, заголовок и бегущая полоска. */
    static void loading(GuiGraphics g, int w, int h, String title) {
        Font f = Minecraft.getInstance().font;
        long ms = System.currentTimeMillis();
        float cx = w / 2f, cy = h / 2f - 14;
        int acc = Config.color() & 0xFFFFFF;
        int head = (int) ((ms / 90) % 12);
        for (int i = 0; i < 12; i++) {
            double ang = i * Math.PI * 2 / 12;
            int d = (head - i + 12) % 12;
            int a = Math.max(40, 255 - d * 20);
            int x = (int) (cx + Math.cos(ang) * 16), y = (int) (cy + Math.sin(ang) * 16);
            CosmeticsScreen.rrect(g, x - 2, y - 2, 4, 4, 2, (a << 24) | acc);
        }
        String s = Tr.tr(title);
        g.pose().pushPose();
        g.pose().translate(cx, cy + 34, 0);
        g.pose().scale(1.4f, 1.4f, 1f);
        g.drawString(f, s, -f.width(s) / 2, 0, 0xFFFFFFFF, false);
        g.pose().popPose();
        int bw = 140, bx = (int) cx - bw / 2, by = (int) cy + 58, seg = 44;
        CosmeticsScreen.rrect(g, bx, by, bw, 4, 2, 0x33FFFFFF);
        int sx = bx + (int) ((bw + seg) * ((ms % 1600) / 1600f)) - seg;
        int x0 = Math.max(bx, sx), x1 = Math.min(bx + bw, sx + seg);
        if (x1 > x0) CosmeticsScreen.rrect(g, x0, by, x1 - x0, 4, 2, 0xFF000000 | acc);
        g.drawCenteredString(f, "FLR Visuals", w / 2, h - 16, 0x66FFFFFF);
    }
}
